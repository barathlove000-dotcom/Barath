# Acer Clean Home

A minimal Android TV home-screen prototype intended for Android TV devices such as the Acer R3 running Android 14. It displays launchable TV/mobile apps in a remote-friendly grid and declares itself as a HOME activity.

## Build an APK without a computer

1. On your phone, open GitHub in a browser and create a new **public** repository named `AcerCleanHome` (or use a private repository if preferred).
2. Upload the contents of this project, preserving the folder structure, to the repository's `main` branch. GitHub's web upload supports selecting multiple files; for easier upload, extract the ZIP first using a file manager and use GitHub's **Add file → Upload files**. Ensure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
4. Select **Build Acer Clean Home APK** and tap **Run workflow**. You can also trigger it by committing/pushing files to `main`.
5. When the workflow finishes successfully, open that run, scroll to **Artifacts**, and download `AcerCleanHome-debug-apk`. Extract the downloaded ZIP on your phone to get `app-debug.apk`.
6. Transfer the APK to the TV using a USB drive or a file-transfer app, then install it. You may need to allow installation from the file manager you use.

## Make it the default Home app

After installation, press Home. If Android presents a Home-app chooser, select **Acer Clean Home** and choose **Always**. If it does not, inspect Settings for Apps → Default apps → Home app (the menu varies by firmware).

The Acer firmware report previously showed `WIZARD_STAYS_ON`; therefore the firmware may block launcher replacement. This app cannot bypass device-owner, firmware, or system restrictions. Keep the original launcher installed and do not disable system packages until the new launcher has been tested.

## Technical notes

- Package: `com.barath.acercleanhome`
- Min SDK: 23; target SDK: 32
- No third-party runtime dependencies
- GitHub Actions builds a debug APK; it is not a Play Store release and is not signed with a private release key.
- This is an initial source project, not tested on the physical Acer R3. TV vendor firmware may expose app launch intents differently.
