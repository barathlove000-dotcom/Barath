package com.barath.acercleanhome

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 18, 22)
    private val tileBg = Color.rgb(31, 35, 43)
    private val textColor = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(166, 175, 188)
    private val pm by lazy { packageManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(44), dp(24), dp(44), dp(24))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "ACER  /  HOME"
            setTextColor(textColor)
            textSize = 24f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEE, d MMM  ·  h:mm a", Locale.getDefault()).format(Date())
            setTextColor(muted)
            textSize = 16f
        }
        header.addView(date)
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Your apps. Nothing extra."
            setTextColor(muted)
            textSize = 16f
            setPadding(0, dp(8), 0, dp(20))
        }
        root.addView(subtitle)

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val grid = GridLayout(this).apply {
            columnCount = 5
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        val apps = queryApps().sortedBy { it.label.toString().lowercase(Locale.getDefault()) }
        if (apps.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = "No launchable apps found. Open Settings to check installed apps."
                setTextColor(textColor); textSize = 18f
            })
        } else {
            apps.forEach { info ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(8), dp(14), dp(8), dp(12))
                    background = rounded(tileBg, dp(14))
                    isFocusable = true
                    isFocusableInTouchMode = true
                    contentDescription = info.label
                    setOnClickListener {
                        try {
                            val launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                                ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                                    .setClassName(info.activityInfo.packageName, info.activityInfo.name)
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                        } catch (_: Exception) { }
                    }
                    setOnFocusChangeListener { view, focused ->
                        view.background = rounded(if (focused) Color.rgb(56, 72, 91) else tileBg, dp(14))
                        view.scaleX = if (focused) 1.04f else 1f
                        view.scaleY = if (focused) 1.04f else 1f
                    }
                }
                val icon = ImageView(this).apply {
                    setImageDrawable(info.loadIcon(pm))
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }
                tile.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
                val label = TextView(this).apply {
                    text = info.loadLabel(pm)
                    setTextColor(textColor)
                    textSize = 14f
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(0, dp(9), 0, 0)
                }
                tile.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
                val lp = GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(112)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
                grid.addView(tile, lp)
            }
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val footer = TextView(this).apply {
            text = "OK / ENTER  ·  Open app       HOME  ·  Return here if selected as default"
            setTextColor(muted)
            textSize = 12f
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
        grid.post { if (grid.childCount > 0) grid.getChildAt(0).requestFocus() }
    }

    private fun queryApps(): List<android.content.pm.ResolveInfo> {
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        val found = linkedMapOf<String, android.content.pm.ResolveInfo>()
        intents.forEach { intent ->
            @Suppress("DEPRECATION")
            val list = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            list.forEach { info ->
                val key = info.activityInfo.packageName + "/" + info.activityInfo.name
                if (info.activityInfo.packageName != packageName) found[key] = info
            }
        }
        return found.values.toList()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
